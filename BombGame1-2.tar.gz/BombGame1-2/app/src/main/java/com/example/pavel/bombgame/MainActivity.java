package com.example.pavel.bombgame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private Button tryBox1, tryBox2, tryBox3, tryBox4, tryBox5, tryBox6, tryBox7, tryBox8, tryBox9, tryBox10, tryBox11, tryBox12, tryBox13, tryBox14, tryBox15, tryBox16,tryBox17,tryBox18,tryBox19,tryBox20;
    private TextView score;
    int CheckBomb = 1;
    String MyScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //MyScore = Integer.toString(myScore);

        //score = (TextView) findViewById(R.id.my);
        //score.setText(MyScore);


        tryBox1 = (Button) findViewById(R.id.test1);
        tryBox1.setOnClickListener(this);
        tryBox1.setOnLongClickListener(this);
        tryBox2 = (Button) findViewById(R.id.test2);
        tryBox2.setOnClickListener(this);
        tryBox2.setOnLongClickListener(this);
        tryBox3 = (Button) findViewById(R.id.test3);
        tryBox3.setOnClickListener(this);
        tryBox3.setOnLongClickListener(this);
        tryBox4 = (Button) findViewById(R.id.test4);
        tryBox4.setOnClickListener(this);
        tryBox4.setOnLongClickListener(this);
        tryBox5 = (Button) findViewById(R.id.test5);
        tryBox5.setOnClickListener(this);
        tryBox5.setOnLongClickListener(this);
        tryBox6 = (Button) findViewById(R.id.test6);
        tryBox6.setOnClickListener(this);
        tryBox6.setOnLongClickListener(this);
        tryBox7 = (Button) findViewById(R.id.test7);
        tryBox7.setOnClickListener(this);
        tryBox7.setOnLongClickListener(this);
        tryBox8 = (Button) findViewById(R.id.test8);
        tryBox8.setOnClickListener(this);
        tryBox8.setOnLongClickListener(this);
        tryBox9 = (Button) findViewById(R.id.test9);
        tryBox9.setOnClickListener(this);
        tryBox9.setOnLongClickListener(this);
        tryBox10 = (Button) findViewById(R.id.test10);
        tryBox10.setOnClickListener(this);
        tryBox10.setOnLongClickListener(this);
        tryBox11 = (Button) findViewById(R.id.test11);
        tryBox11.setOnClickListener(this);
        tryBox11.setOnLongClickListener(this);
        tryBox12 = (Button) findViewById(R.id.test12);
        tryBox12.setOnClickListener(this);
        tryBox12.setOnLongClickListener(this);
        tryBox13 = (Button) findViewById(R.id.test13);
        tryBox13.setOnClickListener(this);
        tryBox13.setOnLongClickListener(this);
        tryBox14 = (Button) findViewById(R.id.test14);
        tryBox14.setOnClickListener(this);
        tryBox14.setOnLongClickListener(this);
        tryBox15 = (Button) findViewById(R.id.test15);
        tryBox15.setOnClickListener(this);
        tryBox15.setOnLongClickListener(this);
        tryBox16 = (Button) findViewById(R.id.test16);
        tryBox16.setOnClickListener(this);
        tryBox16.setOnLongClickListener(this);
        tryBox17 = (Button) findViewById(R.id.test17);
        tryBox17.setOnClickListener(this);
        tryBox17.setOnLongClickListener(this);
        tryBox18 = (Button) findViewById(R.id.test18);
        tryBox18.setOnClickListener(this);
        tryBox18.setOnLongClickListener(this);
        tryBox19 = (Button) findViewById(R.id.test19);
        tryBox19.setOnClickListener(this);
        tryBox19.setOnLongClickListener(this);
        tryBox20 = (Button) findViewById(R.id.test20);
        tryBox20.setOnClickListener(this);
        tryBox20.setOnLongClickListener(this);
    }

    public void onClick(View view) {

        if (CheckBomb == 1) {
            switch (view.getId()) {
                case R.id.test1:
                    tryBox1.setText("1");
                    break;
                case R.id.test2:
                    tryBox2.setText("X");
                    CheckBomb = 2;
                    tryBox1.setText("*");
                    tryBox2.setText("X");
                    tryBox3.setText("*");
                    tryBox4.setText("*");
                    tryBox5.setText("X");
                    tryBox6.setText("*");
                    tryBox7.setText("*");
                    tryBox8.setText("*");
                    tryBox9.setText("*");
                    tryBox10.setText("*");
                    tryBox11.setText("*");
                    tryBox12.setText("X");
                    tryBox13.setText("*");
                    tryBox14.setText("*");
                    tryBox15.setText("*");
                    tryBox16.setText("X");
                    tryBox17.setText("*");
                    tryBox18.setText("*");
                    tryBox19.setText("X");
                    tryBox20.setText("*");
                    break;
                case R.id.test3:
                    tryBox3.setText("3");
                    break;
                case R.id.test4:
                    tryBox4.setText("2");
                    break;
                case R.id.test5:
                    tryBox5.setText("X");
                    CheckBomb = 2;
                    tryBox1.setText("*");
                    tryBox2.setText("X");
                    tryBox3.setText("*");
                    tryBox4.setText("*");
                    tryBox5.setText("X");
                    tryBox6.setText("*");
                    tryBox7.setText("*");
                    tryBox8.setText("*");
                    tryBox9.setText("*");
                    tryBox10.setText("*");
                    tryBox11.setText("*");
                    tryBox12.setText("X");
                    tryBox13.setText("*");
                    tryBox14.setText("*");
                    tryBox15.setText("*");
                    tryBox16.setText("X");
                    tryBox17.setText("*");
                    tryBox18.setText("*");
                    tryBox19.setText("X");
                    tryBox20.setText("*");
                    break;
                case R.id.test6:
                    tryBox6.setText("2");
                    break;
                case R.id.test7:
                    tryBox7.setText("2");
                    break;
                case R.id.test8:
                    tryBox8.setText("2");
                    break;
                case R.id.test9:
                    tryBox9.setText("1");
                    break;
                case R.id.test10:
                    tryBox10.setText("1");
                    break;
                case R.id.test11:
                    tryBox11.setText("2");
                    break;
                case R.id.test12:
                    tryBox12.setText("X");
                    CheckBomb = 2;
                    tryBox1.setText("*");
                    tryBox2.setText("X");
                    tryBox3.setText("*");
                    tryBox4.setText("*");
                    tryBox5.setText("X");
                    tryBox6.setText("*");
                    tryBox7.setText("*");
                    tryBox8.setText("*");
                    tryBox9.setText("*");
                    tryBox10.setText("*");
                    tryBox11.setText("*");
                    tryBox12.setText("X");
                    tryBox13.setText("*");
                    tryBox14.setText("*");
                    tryBox15.setText("*");
                    tryBox16.setText("X");
                    tryBox17.setText("*");
                    tryBox18.setText("*");
                    tryBox19.setText("X");
                    tryBox20.setText("*");
                    break;
                case R.id.test13:
                    tryBox13.setText("1");
                    break;
                case R.id.test14:
                    tryBox14.setText("1");
                    break;
                case R.id.test15:
                    tryBox15.setText("1");
                    break;
                case R.id.test16:
                    tryBox16.setText("X");
                    CheckBomb = 2;
                    tryBox1.setText("*");
                    tryBox2.setText("X");
                    tryBox3.setText("*");
                    tryBox4.setText("*");
                    tryBox5.setText("X");
                    tryBox6.setText("*");
                    tryBox7.setText("*");
                    tryBox8.setText("*");
                    tryBox9.setText("*");
                    tryBox10.setText("*");
                    tryBox11.setText("*");
                    tryBox12.setText("X");
                    tryBox13.setText("*");
                    tryBox14.setText("*");
                    tryBox15.setText("*");
                    tryBox16.setText("X");
                    tryBox17.setText("*");
                    tryBox18.setText("*");
                    tryBox19.setText("X");
                    tryBox20.setText("*");
                    break;
                case R.id.test17:
                    tryBox17.setText("2");
                    break;
                case R.id.test18:
                    tryBox18.setText("3");
                    break;
                case R.id.test19:
                    tryBox19.setText("X");
                    CheckBomb = 2;
                    tryBox1.setText("*");
                    tryBox2.setText("X");
                    tryBox3.setText("*");
                    tryBox4.setText("*");
                    tryBox5.setText("X");
                    tryBox6.setText("*");
                    tryBox7.setText("*");
                    tryBox8.setText("*");
                    tryBox9.setText("*");
                    tryBox10.setText("*");
                    tryBox11.setText("*");
                    tryBox12.setText("X");
                    tryBox13.setText("*");
                    tryBox14.setText("*");
                    tryBox15.setText("*");
                    tryBox16.setText("X");
                    tryBox17.setText("*");
                    tryBox18.setText("*");
                    tryBox19.setText("X");
                    tryBox20.setText("*");
                    break;
                case R.id.test20:
                    tryBox20.setText("1");
                    break;
            }
        }
    }
    @Override
    public boolean onLongClick(View view) {

        if (CheckBomb == 1) {
            switch (view.getId()) {
                case R.id.test1:
                    tryBox1.setText("?");
                    break;
                case R.id.test2:
                    tryBox2.setText("?");
                    break;
                case R.id.test3:
                    tryBox3.setText("?");
                    break;
                case R.id.test4:
                    tryBox4.setText("?");
                    break;
                case R.id.test5:
                    tryBox5.setText("?");
                    break;
                case R.id.test6:
                    tryBox6.setText("?");
                    break;
                case R.id.test7:
                    tryBox7.setText("?");
                    break;
                case R.id.test8:
                    tryBox8.setText("?");
                    break;
                case R.id.test9:
                    tryBox9.setText("?");
                    break;
                case R.id.test10:
                    tryBox10.setText("?");
                    break;
                case R.id.test11:
                    tryBox11.setText("?");
                    break;
                case R.id.test12:
                    tryBox12.setText("?");
                    break;
                case R.id.test13:
                    tryBox13.setText("?");
                    break;
                case R.id.test14:
                    tryBox14.setText("?");
                    break;
                case R.id.test15:
                    tryBox15.setText("?");
                    break;
                case R.id.test16:
                    tryBox16.setText("?");
                    break;
                case R.id.test17:
                    tryBox17.setText("?");
                    break;
                case R.id.test18:
                    tryBox18.setText("?");
                    break;
                case R.id.test19:
                    tryBox19.setText("?");
                    break;
                case R.id.test20:
                    tryBox20.setText("?");
                    break;

            }
        }
            return true;
    }
}
